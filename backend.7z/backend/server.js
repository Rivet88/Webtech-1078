const express = require('express')
const bodyParser = require('body-parser')
const Sequelize = require('sequelize')

const sequelize = new Sequelize('bd', 'dianaene512', '', {
  dialect : 'mysql',
  define : {
    timestamps : false
  }
})

const Field = sequelize.define('field', {
    name: Sequelize.STRING,
    description: Sequelize.STRING
}, {
  underscored : true
})

const Paper = sequelize.define('paper', {
   name: Sequelize.STRING,
    description: Sequelize.STRING,
    price: Sequelize.INTEGER,
    image: Sequelize.STRING
})

Field.hasMany(Paper)

const app = express()
app.use(bodyParser.json())


app.use(function(req, res, next) {
   res.header("Access-Control-Allow-Origin", "*");
   res.header('Access-Control-Allow-Methods', 'DELETE, PUT, GET, POST');
   res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
   next();
});

app.use(express.static('../frontend/build'))




app.get('/create', (req, res, next) => {
  sequelize.sync({force : true})
    .then(() => res.status(201).send('created'))
    .catch((error) => next(error))
})

app.get('/fields', (req, res, next) => {
  Field.findAll()
    .then((user) => res.status(200).json(user))
    .catch((error) => next(error))
})

app.post('/fields', (req, res, next) => {
  Field.create(req.body)
    .then(() => res.status(201).send('created'))
    .catch((error,msg) => {next(error, msg)
      
    })
})

app.get('/fields/:id', (req, res, next) => {
  Field.findById(req.params.id)
    .then((user) => {
      if (user){
        res.status(200).json(user)
      }
      else{
        res.status(404).send('not found')
      }
    })
    .catch((error) => next(error))
})

app.put('/fields/:id', (req, res, next) => {
  Field.findById(req.params.id)
    .then((user) => {
      if (user){
        return user.update(req.body)
      }
      else{
        res.status(404).send('not found')
      }
    })
    .then(() => {
      if (!res.headersSent){
        res.status(201).send('modified')
      }
    })
    .catch((error) => next(error))
})

app.delete('/fields/:id', (req, res, next) => {
  Field.findById(req.params.id)
    .then((user) => {
      if (user){
        return user.destroy()
      }
      else{
        res.status(404).send('not found')
      }
    })
    .then(() => {
      if (!res.headersSent){
        res.status(201).send('modified')
      }
    })
    .catch((error) => next(error))
})

app.get('/fields/:cid/papers', (req, res, next) => {
  Field.findById(req.params.cid)
    .then((user) => {
      if(user){
        return user.getPapers()
      }
      else{
        res.status(404).send('not found')
      }
    })
    .then((paper) => {
      if (!res.headersSent){
        res.status(200).json(paper)
      }
    })
    .catch((err) => next(err))
})

app.post('/fields/:cid/papers', (req, res, next) => {
  Field.findById(req.params.cid)
    .then((field) => {
      if(field){
        let paper = req.body
        paper.field = field.id
        paper.image = "somelink"
        return Paper.create(paper)
      }
      else{
        res.status(404).send('not found')
      }
    })
    .then(() => {
      if (!res.headersSent){
        res.status(201).send('created')
      }
    })
    .catch((err) => next(err))
})

app.get('/fields/:cid/papers/:pid', (req, res, next) => {
  Paper.findById(req.params.pid)
    .then((paper) => {
      if (paper){
        res.status(200).json(paper)
      }
      else{
        res.status(404).send('not found')
      }
    })
    .catch((err) => next(err))
})

app.put('/fields/:cid/papers/:pid', (req, res, next) => {
  Paper.findById(req.params.id)
    .then((paper) => {
      if (paper){
        return paper.update(req.body)
      }
      else{
        res.status(404).send('not found')
      }
    })
    .then(() => {
      if (!res.headersSent){
        res.status(201).send('modified')
      }
    })
    .catch((err) => next(err))  
})

app.delete('/fields/:cid/papers/:pid', (req, res, next) => {
  Paper.findById(req.params.id)
    .then((paper) => {
      if (paper){
        return paper.destroy()
      }
      else{
        res.status(404).send('not found')
      }
    })
    .then(() => {
      if (!res.headersSent){
        res.status(201).send('removed')
      }
    })
    .catch((err) => next(err))
})

app.use((err, req, res, next) => {
  console.warn(err)
  res.status(500).send('some error...')
})

app.listen(8080)